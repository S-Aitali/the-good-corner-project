<div class="container">
  <div class="row">
  <?php
        $data = Items::getAllFromDb($conn, 20);
        foreach ($data as $article) {
    ?>
     <div class= "clo-md-6 col-lg-3">
        <div class="card">
        <?php if (!empty($article->primaryImage)) { ?>
                <img src='data:image/jpeg;base64,<?php echo base64_encode( $article->primaryImage )?>' class="card-img-top"/>
              <?php } ?>
        <div class= "card-block">
        
            <span><?php echo $article->itemDescription ?></span>
        </br>
            <span><?php echo "$ $article->itemPrice" ?></span>
        </div>
      </div>
    </div>
     <?php
        }
    ?>




