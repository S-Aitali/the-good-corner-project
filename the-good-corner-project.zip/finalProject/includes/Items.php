<?php
class Items {
    // parameters
    public $conn;
    public $itemId;
    //public $userID;
    public $primaryImage;
    public $imageTitle;
    public $itemName;
    public $itemDescription;
    public $itemPrice;
    
    //public $userItemId;

    function __construct($conn, $itemInfo) {
        $this->conn = $conn;
        $this->itemId = $itemInfo['itemID'];
        //$this->userID = $itemInfo['userID'];
        $this->itemName = $itemInfo['itemName'];
        $this->primaryImage = $itemInfo['primaryImage'];
        $this->imageTitle = $itemInfo['imageTitle'];
        $this->itemDescription = $itemInfo['itemDescription'];
        $this->itemPrice = $itemInfo['itemPrice'];
       
    }

    function __destruct() { }

    static function getItemFromDb($conn, $itemID) {
        $selectItems = "SELECT * FROM items
        WHERE items.itemID=:itemID";
        $stmt = $conn->prepare($selectItems);
        $stmt->bindParam(':itemID', $itemID, PDO::PARAM_INT);
        //$stmt->bindParam(':numItems', $numItems, PDO::PARAM_INT);
        $stmt->execute();
       
        $articleList = array();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        foreach($stmt->fetchAll() as $listRow) {
            $article = new Items($conn, $listRow);
            $articleList[] = $article;
        }
    
        return $articleList;
    }

    static function getAllFromDb($conn, $number) {
        $selectItems = "SELECT * FROM items
        LIMIT :number";
        $stmt = $conn->prepare($selectItems);
        $stmt->bindParam(':number', $number, PDO::PARAM_INT);
        $stmt->execute();
       
        $articleList = array();
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        foreach($stmt->fetchAll() as $listRow) {
            $article = new Items($conn, $listRow);
            $articleList[] = $article;
        }
    
        return $articleList;
    }

    function createItem() {
        $insert = "INSERT INTO items
            (itemName, itemDescription, itemPrice, primaryImage, imageTitle)
            VALUES
            (:itemName, :itemDescription, :itemPrice, :primaryImage, :imageTitle)";
        $stmt = $this->conn->prepare($insert);
        $stmt->bindParam(':itemName', $this->itemName);
        $stmt->bindParam(':itemDescription', $this->itemDescription);
        $stmt->bindParam(':itemPrice', $this->itemPrice);
        $stmt->bindParam(':primaryImage', $this->primaryImage);
        $stmt->bindParam(':imageTitle', $this->imageTitle);
        $stmt->execute();
    }

    
}
