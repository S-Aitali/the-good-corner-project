<?php
include("../includes/navbar.php");

if (isset($_GET['itemId'])) {
    try {
        $data = Items::getItemFromDb($conn, $_GET['itemId']);
    } catch(Exception) {
        header("Location: 404.php");
    }
   
} else {
    header("Location: 404.php");
}
$data = Items::getItemFromDb($conn, $_GET['itemId']);
?>

<div class="container">
<?php
      foreach ($data as $article) {
	  $itemId = $article->itemId;
  ?>
                <div>
                <?php if (!empty($article->primaryImage)) { ?>
                <img src='data:image/jpeg;base64,<?php echo base64_encode( $article->primaryImage )?>' width="130" height="100"/>
              <?php } ?>
               </div>
                Item Description: <br></br> <?php echo $article->itemDescription; ?>
                <br></br>
                Item Price: <?php echo $article->itemPrice; ?>
            </div>
            <div class="col-12 col-md-5 text-end">
              
              <br></br>
            </div>
          </div>
      </div>
    
  <?php
    }
  ?>
</div>
      


