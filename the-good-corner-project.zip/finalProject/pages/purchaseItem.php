<?php
include("../includes/navbar.php");
$data = Items::getAllFromDb($conn, 20);
?>

<style>
  .product{
   border: 1px solid #eaeaec;
   margin: -1px 19px 3px -1px;
   padding: 10px;
   text-align: center;
   background-color: #efefef;
  }
</style>


  <?php
  $addButton = "Add to Cart";
 /* if ($_SERVER["REQUEST_METHOD"] == "POST") {
     if(isset($_POST["add"])){
      $addButton = "Added";
    }
  }*/
  
      foreach ($data as $article) {
        $itemId = $article->itemId;
?>
  <div class="col-md-3" style="display: inline-block">
  <form method="post" action="cart.php?action=add&id=<?php echo $itemId ?>">
  
              <div class="product">
              <a class="" href="viewItem.php?itemId=<?php echo $itemId ?>">
                <?php if (!empty($article->primaryImage)) { ?>
                <img src='data:image/jpeg;base64,<?php echo base64_encode( $article->primaryImage )?>' width="130" height="100"/>
              <?php } ?> <br>
                <span class="text-info"><?php echo $article->itemDescription ?></span><br>
                 <span class="text-danger"><?php echo "$ $article->itemPrice" ?></span>
              </a>
           
              <input type="text" name="quantity" class="form-control" value="1"><br>
              <input type="hidden" name="hidden_name" value= "<?php echo $article->itemName ?>">
              <input type="hidden" name="hidden_price" value= "<?php echo $article->itemPrice ?>">
        <label for="submit"></label>
        <input type="submit" name="add" class="btn btn-success" value="<?php echo $addButton?>">
                </div>
               
      </form>
                </div>
  <?php
    }
  ?>

  
