<?php
include("../includes/navbar.php");
$data = Items::getAllFromDb($conn, 10);


if(isset($_POST["add"])){
  if(isset($_SESSION["cart"])){
   $item_array_id = array_column($_SESSION['cart'], "product_id");
   if(!in_array($_GET["id"], $item_array_id)){
    $count = count ($_SESSION["cart"]);
    $item_array = array(
      'product_id' => $_GET["id"],
      'item_name' => $_POST["hidden_name"],
      'product_price' => $_POST["hidden_price"],
      'item_quantity' => $_POST["quantity"],
    );
    $_SESSION["cart"][$count] = $item_array;
    echo '<script>"cart.php"</script>';
     }else{
      echo '<script> alert("Item is already added to Cart")</script>';
      echo '<script>"cart.php"</script>';
     }
    }else{
      $item_array = array(
        'product_id' => $_GET["id"],
        'item_name' => $_POST["hidden_name"],
        'product_price' => $_POST["hidden_price"],
        'item_quantity' => $_POST["quantity"],
      );
    $_SESSION["cart"][0] = $item_array;
     }
    }
if(isset($_GET["action"])){
  if($_GET["action"] == "delete"){
    foreach($_SESSION["cart"] as $keys => $value){
      if($value["product_id"] == $_GET["id"]){
        unset($_SESSION["cart"][$keys]);
        echo'<script> alert("Item has been removed from cart")</script>';
        echo '<script>"cart.php"</script>';
      }
    }
  }
}

?>
<style>
  table, th, tr{
    text-align:center;
  }
 
  .title2{
    text-align: center;
    color: #66afe9;
    background-color: #efefef;
    padding: 2%;
  }
  h2{
    text-align: center;
    color: #66afe9;
    background-color: #efefef;
    padding: 2%;
  }
  table th{
    background-color: #efefef;
  }
  </style>
<div style="clear: both"></div>
<h3 class="title2">Shopping Cart Details</h3>
<div class="table_responsive">
  <table class= "table table_bordered">
     <tr>
         <th width="30%"> Product Name </th>
         <th width="10%">quantity </th>
         <th width = "13%"> Price Details </th>
         <th width="10%"> Total Price </th>
         <th width="17%"> Remove Item </th>
    </tr>

    <?php
if(!empty($_SESSION["cart"])){
  $total = 0;
  foreach ($_SESSION["cart"] as $key => $value){
   ?>
<tr> 
    <td><?php echo $value["item_name"] ?></td>
    <td><?php echo $value["item_quantity"]?></td>
    <td><?php echo $value["product_price"]?></td>
    <td> $ <?php echo number_format( $value["item_quantity"] * $value["product_price"], 2);?></td>
    <td><a href="cart.php?action=delete&id=<?php echo $value["product_id"];?>"><span  class= "btn btn-danger" > Remove Item </span></a></td>
</tr>

<?php
$total = $total + ($value["item_quantity"] * $value["product_price"]);
?>

<tr> 
  <th colspan="3" align="right" > Total </th>
  <td align="right"> $ <?php echo number_format($total, decimals:2); ?></td> 
  <td></td>
 </tr>

<?php
  }
}
  ?>
</table>
</div>
</div>

<div style="text-align: center">
  <a href="../pages/checkout.php" class="btn btn-outline-primary"> Proceed To Checkout </a>
</div>




     