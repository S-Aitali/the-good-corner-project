<?php
  include("../includes/navbar.php");
 
  //session_start();

  if (isset($_SESSION['userName'])) {
?>
<style>
    body {
 background-image: url("../images/moneyBack.JPG");
    }
    </style>

<div class='container'>
    <div class="row">
        <div class="col-12 col-lg-6 offset-lg-3">
            <h1>Hello <?php echo $_SESSION['userName'] ?></h1>
            <a class="btn btn-primary" href="purchaseItem.php">Make a purchase</a>
        </div>
    </div>
</div>

<?php
} else {
    header("Location: ../pages/homepage.php");
}
?>

