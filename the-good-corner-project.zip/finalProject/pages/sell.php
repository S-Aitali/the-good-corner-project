<?php
include("../includes/navbar.php");
$imageErr = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $mbFileSize = $_FILES["fileToUpload"]["size"] / 1000000;
      if ($mbFileSize > 10) {
          $imageErr = "Your file is too large. Max file size is 10MB. Yours was $mbFileSize MB";
      }

      $itemName = clean_input($_POST["itemName"]);
      $itemPrice = clean_input($_POST["itemPrice"]);
      $itemDescription = clean_input($_POST["itemDescription"]);
      $primaryImage = file_get_contents($_FILES['fileToUpload']['tmp_name']); 
       
      $imageTitle = htmlspecialchars($_FILES["fileToUpload"]["name"]);

      if (!empty($itemName) && !empty($itemDescription) && !empty($itemPrice) ) {
        //$itemId = $_SESSION['itemID'];
    
        $itemInfo = array(
          "itemID" => "",
          "itemName" => $itemName,
          "itemDescription" => $itemDescription,
          "itemPrice" => $itemPrice,
          "primaryImage" => $primaryImage,
        "imageTitle" => $imageTitle
        );

        $article = new Items($conn, $itemInfo);
        $article->createItem(); 
        header("Location: purchaseItem.php");
    }
}
?>




<style>
    .error {color: #FF0000;}
    .myForm{border: 3px outset white; width: 800px; height: 500px; background-color: #ADADC9; margin: auto; padding: 30px 30px; text-shadow: 2px 2px lightblue; border-radius: 25px;}
    input[type=text]{background-color:  #E6E6FA; border: white; border-radius: 20px; height: 40px; text-align: center; }
    input[type=submit]{background-color: #7852A9; cursor: pointer; border: white; border-radius: 20px; padding: 10px 30px; font-weight: bold; font-size: 15px;   }
    input[type=password]{background-color:  #E6E6FA; border: white; border-radius: 20px; height: 40px; text-align: center; }   
</style>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-10 col-lg-8 col-xl-7">
      <form class="myForm" enctype="multipart/form-data"  method="post" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <div class="form-group">
          <label for="title">Item Name</label>
          <span class="error">*</span><br>
          <input type="text" class="form-control" name="itemName" id="title" required>
          <label for="title">Item Price</label>
          <span class="error">*<br>
          <input type="text" class="form-control" name="itemPrice" id="title" required>
        </div>

        <div class="form-group">
            <label for="fileToUpload">Select image to upload:</label>
            <input type="file" name="fileToUpload" id="fileToUpload" >
            <span class="error">* <?php echo $imageErr;?></span><br>
        </div>

        <div class="form-group">
          <label for="content">Item Description</label>
          <span class="error">*<br>
          <textarea rows="5" class="form-control" name="itemDescription" id="content" required></textarea>
        </div>
       
        <input type="submit" class="btn btn-primary" value="Submit">
    </form>    
    </div>
  </div>
</div>

        
