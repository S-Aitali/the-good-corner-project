<?php
include("../includes/navbar.php");
if(isset($_POST["order"])){
  echo '<script> alert("Order Processed. Thank you for shopping with us!")</script>';
}
?>
<style>
    .error {color: #FF0000;}
    .myForm{border: 3px outset white; width: 800px; height: 400px; background-color: #ADADC9; margin: auto; padding: 30px 30px; text-shadow: 2px 2px lightblue; border-radius: 25px;}
    input[type=text]{background-color:  #E6E6FA; border: white; border-radius: 20px; height: 30px; text-align: center; }
    input[type=submit]{background-color: #7852A9; cursor: pointer; border: white; border-radius: 20px; padding: 10px 30px; font-weight: bold; font-size: 15px; color: white;   }
      
</style>

 <div class="row">
  <div class="col-75">
    <div class="container">
    <form method="post" action="" class="myForm">

        <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" id="fname" name="firstname" placeholder="John M. Doe"></br>
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" id="email" name="email" placeholder="john@example.com"></br>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="address" placeholder="542 W. 15th Street"></br>
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="city" placeholder="New York"></br>

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                <input type="text" id="state" name="state" placeholder="NY">
              </div>
              <div class="col-50">
                <label for="zip">Zip</label>
                <input type="text" id="zip" name="zip" placeholder="10001">
              </div>
            </div>
          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" id="cname" name="cardname" placeholder="John More Doe">
            <label for="ccnum">Credit card number</label>
            <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444">
            <label for="expmonth">Exp Month</label>
            <input type="text" id="expmonth" name="expmonth" placeholder="September">

            <div class="row">
              <div class="col-50">
                <label for="expyear">Exp Year</label>
                <input type="text" id="expyear" name="expyear" placeholder="2018">
              </div>
              <div class="col-50">
                <label for="cvv">CVV</label>
                <input type="text" id="cvv" name="cvv" placeholder="352">
              </div>
            </div>
          </div>

        </div>
        <label>
          <input type="checkbox" checked="checked" name="sameadr"> Shipping address same as billing
        </label></br>
        <input type="submit" name="order" value="Place Order" class="btn" style="margin-left: 300px;">
      </form>
    </div>
  </div>

  <div class="col-25">
    <div class="container">
        <?php
        $count = count ($_SESSION["cart"])
        ?>
      <h4>Cart
        <span class="price" style="color:black">
          <i class="fa fa-shopping-cart"></i>
          <b><?php echo $count ?></b>
        </span>
      </h4>
      <?php
      if(!empty($_SESSION["cart"])){
        $total = 0;
      foreach ($_SESSION["cart"] as $key => $value){
   ?>
      <a href="#"><span> <?php echo $value["item_name"] ?> </span></a> 
      <span><?php echo '$' . $value["product_price"]?></span>
      <span><?php echo 'x' . $value["item_quantity"]?></span>
      <hr>
      
    <?php
$total = $total + ($value["item_quantity"] * $value["product_price"]);
?>

     
<?php
      }
      ?>
      <h5> Total: </h5>
      <span> $ <?php echo number_format($total, decimals:2); ?></span>
      <?php
    }
?>
    </div>
  </div>
</div> 


      
   
     
     
    
      
      
  
  






     