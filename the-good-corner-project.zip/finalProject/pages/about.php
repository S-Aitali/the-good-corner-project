<?php
  include("../includes/navbar.php");
?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="../includes/styleSheet.css"> 
    </head>
  <body>

  <p id=description>
    We collect different objects that are still in good condition,</br>
    We don't accept broken items in our corner. </br>
    That what makes it the good corner for us and for our customers. </br>
    By items for less and save money!
  </p>
    <div>
        <div class=divCollection>
  <img src="../images/collection1.jpg" class="d-block w-100" alt="we collect items for you"  width="300" height="300">
    </div>
    <div class=divCollection>
  <img src="../images/collection2.jpg" class="d-block w-100" alt="we collect items for you"  width="300" height="300">
    </div>
</div>

    <div class=fullImage>
    <p> With The Good Corner, you don't need to find the righ place to sale your items anymore!
         Just upload a picture and sold everything online. </p>
<img src="../images/collection3.jpg" class="d-block w-100" alt="we collect items for you" width="1000" height="500">
    </div>
