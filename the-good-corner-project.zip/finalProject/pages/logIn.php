<?php
include("../includes/navbar.php");
 
$name = $username = $password = "";
$passwordErr = $usernameErr = "";
 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $username = clean_input($_POST["username"]);
  $password = clean_input($_POST["password"]);

  if (!empty($username) && !empty($password)) {
    $usernameErr = verifyUser($username);
    $passwordErr = verifyPassword($username, $password);
    if (empty($usernameErr) && empty($passwordErr)) {
        login($username);
      }
    }
}
    function login($username) {
       // session_start();
        $_SESSION['userName'] = $username;
        $_SESSION['userID'] = getUserId($username);
        header("Location: splashPage.php");
      }
      

function verifyPassword($username, $password) {
    $conn = connect_to_db("finalProjectSara");
    $selectUser = "SELECT userName, userPassword FROM users WHERE userName=:userName";
    $stmt = $conn->prepare($selectUser);
    $stmt->bindParam(':userName', $username);
    $stmt->execute();
  
    $stmt->setFetchMode(PDO::FETCH_ASSOC);
    foreach($stmt->fetchAll() as $listRow) {
      $hashedPassword = $listRow['userPassword'];
      if (!password_verify($password, $hashedPassword)) {
        return "Incorrect password";
  
    }
  }
}
  
function verifyUser($username) {
  $conn = connect_to_db("finalProjectSara");
  $selectUser = "SELECT userName FROM users WHERE userName=:userName";
  $stmt = $conn->prepare($selectUser);
  $stmt->bindParam(':userName', $username);
  $stmt->execute();

  $stmt->setFetchMode(PDO::FETCH_ASSOC);
  return empty($stmt->fetchAll()) ? "Username does not exist" : "";
}
?>


<style>
    .error {color: #FF0000;}
    .myForm{border: 3px outset white; width: 800px; background-color: #ADADC9; margin: auto; padding: 30px 30px; text-shadow: 2px 2px lightblue; border-radius: 25px;}
    input[type=text]{background-color:  #E6E6FA; border: white; border-radius: 20px; height: 40px; text-align: center; }
    input[type=password]{background-color:  #E6E6FA; border: white; border-radius: 20px; height: 40px; text-align: center; }
    input[type=submit]{background-color: #7852A9; cursor: pointer; border: white; border-radius: 20px; padding: 10px 30px; font-weight: bold; font-size: 15px;   }
</style>
<div class='userLoginForm container myForm'>
    <div class="row">
        <div class="col-12 col-lg-6 offset-lg-3">
            <form method="post" action="<?php htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                <div class="form-group">
                    <label for="username">Username</label>
                    <span class="error">* <?php echo $usernameErr;?></span><br>
                    <input type="text" class="form-control" name="username" id="username" required>
                </div>
                <div class="form-group">
                    <label for="password1">Password</label>
                    <span class="error">* <?php echo $passwordErr;?></span><br>
                    <input type="password" class="form-control" name="password" id="password" required>
                </div>
                <input type="submit" class="btn btn-primary" value="Submit">
            </form>
        </div>
    </div>
</div>
